"""Evaluation framework for cortical text processor."""
from .evaluator import CorticalEvaluator
