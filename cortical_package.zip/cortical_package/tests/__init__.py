"""Test suite for cortical text processing package."""
